self.__precacheManifest = [
  {
    "revision": "605e2a7f6e8eab7c4f15",
    "url": "/static/css/main.0599e5a9.chunk.css"
  },
  {
    "revision": "605e2a7f6e8eab7c4f15",
    "url": "/static/js/main.575da856.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "ba264cd90c4d36546d5a",
    "url": "/static/js/2.8f71a45e.chunk.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  },
  {
    "revision": "f608efb45ad7bb84e24a0fd024c86b05",
    "url": "/index.html"
  }
];